# TV Widget Lab

Android TV-only floating dashboard prototype. The app is designed to leave the Google TV launcher unchanged and only show its overlay when launched by the user.

## Current milestone
- Compact status bar with clock, date, RAM and internal data-partition storage readings.
- PANEL button opens a separate expanded dashboard overlay.
- Expanded sections: System Monitor, Network, Everyday, Controls and Settings.
- Panel starts at approximately 40% of screen width and can be resized with the header −/+ controls or D-pad left/right while a panel control has focus.
- Closing the expanded panel leaves the compact bar visible. The compact bar × hides the overlay.
- Refresh Readings only refreshes measurements; it does not close apps or change settings.
- Free RAM is a safe app-management entry point. Android does not allow this normal app to silently force-stop other apps.
- CPU and temperature explicitly show unavailable until reliable device readings are verified.
- Phone guard remains in place: the overlay cannot be launched on a phone.

## Build
GitHub Actions builds `app-debug.apk` on pushes to `main` or by manual workflow dispatch. Open Actions → Build TV Widget Lab APK → latest successful run → Artifacts.

## Important testing notes
A successful build does not guarantee every overlay behavior works on every TV firmware. Test on the target TCL Android TV. Grant the app "Display over other apps" permission first. Home-key detection and overlay focus behavior are vendor/version dependent.

## Not implemented yet
Remote global shortcuts, true app memory reclamation, CPU/temperature sensors, detailed Wi-Fi readings, stopwatch, profiles, widget gallery, and appearance customization are later milestones.
