package com.tvwidgetlab

import android.app.Activity
import android.app.AlertDialog
import android.app.ActivityManager
import android.content.Intent
import android.content.ActivityNotFoundException
import android.media.AudioManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.GradientDrawable
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Full-screen TV Widget Lab shell. It is a separate app; it never replaces Google TV. */
class MainActivity : Activity() {
    companion object { const val EXTRA_CLEAN_MEMORY = "com.tvwidgetlab.extra.CLEAN_MEMORY"; const val EXTRA_START_PAGE = "com.tvwidgetlab.extra.START_PAGE" }
    private val glassOpacity get() = prefs.getInt("glass_opacity", 62).coerceIn(35, 85)
    private val bg get() = if (prefs.getBoolean("glass", true)) Color.rgb(5, 12, 22) else Color.BLACK
    private val surface get() = if (prefs.getBoolean("glass", true)) Color.argb((glassOpacity * 1.85f).toInt().coerceIn(70, 170), 82, 101, 119) else Color.rgb(12, 12, 14)
    private val surface2 get() = if (prefs.getBoolean("glass", true)) Color.argb((glassOpacity * 1.45f).toInt().coerceIn(55, 140), 112, 129, 145) else Color.rgb(24, 24, 27)
    private fun screenBackground(): android.graphics.drawable.Drawable {
        if (!prefs.getBoolean("glass", true)) return ColorDrawable(Color.BLACK)
        // Android 11 compatible frosted backdrop: use a softly pre-blurred scenic layer.
        // This avoids expensive real-time blur while keeping the scenery visible beneath glass surfaces.
        val bitmap = BitmapFactory.decodeResource(resources, R.drawable.glass_scenery_frosted)
        val image = BitmapDrawable(resources, bitmap).apply { gravity = Gravity.FILL }
        val scrim = ColorDrawable(Color.argb((255 - glassOpacity * 2.2f).toInt().coerceIn(55, 150), 5, 12, 20))
        return LayerDrawable(arrayOf(image, scrim))
    }
    private val isPhone get() = resources.configuration.smallestScreenWidthDp < 600
    private fun accentFor(value: Int): Int = when { value >= 85 -> Color.rgb(255, 83, 83); value >= 70 -> Color.rgb(255, 176, 64); else -> Color.rgb(46, 211, 160) }
    private fun roundedBackground(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private val cyan = Color.rgb(67, 211, 235)
    private val muted = Color.rgb(166, 190, 211)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var currentPage = "Home"
    private var activityResumed = false
    private val prefs by lazy { getSharedPreferences("tvlab", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var stopwatchBase = 0L
    private var stopwatchElapsed = 0L
    private var stopwatchRunning = false
    private val aiExecutor = Executors.newSingleThreadExecutor()
    private val aiService by lazy { AiService(this) }
    private var tts: TextToSpeech? = null
    private val stopwatchLaps = mutableListOf<Long>()
    private var everydayClock: TextView? = null
    private var stopwatchDisplay: TextView? = null
    private val ticker = object : Runnable { override fun run() { if (activityResumed && currentPage == "Everyday") { updateEverydayDisplay(); handler.postDelayed(this, 1000L) } } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        stopwatchElapsed = prefs.getLong("stopwatch_elapsed", 0L)
        stopwatchRunning = false
        stopwatchLaps.addAll(prefs.getString("stopwatch_laps", "")!!.split(",").mapNotNull { it.toLongOrNull() })
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        if (intent.getBooleanExtra(EXTRA_CLEAN_MEMORY, false)) renderCleanupScreen() else showPage(intent.getStringExtra(EXTRA_START_PAGE) ?: "Home")
        handler.post(ticker)
    }
    override fun onDestroy() { handler.removeCallbacks(ticker); tts?.shutdown(); aiExecutor.shutdownNow(); super.onDestroy() }
    override fun onBackPressed() { if (currentPage != "Home") showPage("Home") else super.onBackPressed() }
    override fun onPause() {
        activityResumed = false
        handler.removeCallbacks(ticker)
        super.onPause()
        if (stopwatchRunning) { stopwatchElapsed += System.currentTimeMillis() - stopwatchBase; stopwatchRunning = false }
        saveStopwatch()
    }
    override fun onResume() {
        super.onResume()
        activityResumed = true
        handler.removeCallbacks(ticker)
        if (currentPage == "Everyday") handler.post(ticker)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(3), dp(4), dp(3), dp(4))
    }
    private fun card(title: String, value: String, detail: String = ""): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); background = roundedBackground(surface2, 18)
        addView(text(title.uppercase(Locale.getDefault()), 11f, cyan, true)); addView(text(value, 22f, Color.WHITE, true))
        if (detail.isNotBlank()) addView(text(detail, 12f, muted))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.setMargins(dp(5), dp(5), dp(5), dp(5)); layoutParams = lp
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = if (isPhone) 13f else 14f; setTextColor(Color.WHITE); background = roundedBackground(surface2, 16)
        isFocusable = true; isFocusableInTouchMode = true; minHeight = dp(48); setPadding(dp(12), dp(5), dp(12), dp(5))
        setOnFocusChangeListener { v, focus -> v.background = roundedBackground(if (focus) Color.rgb(0, 116, 143) else surface2, 16); v.scaleX = if (focus) 1.025f else 1f; v.scaleY = if (focus) 1.025f else 1f }
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, dp(4), 0, dp(4)); layoutParams = lp
    }
    private fun showPage(page: String) {
        handler.removeCallbacks(ticker)
        currentPage = page
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = screenBackground()
            setPadding(dp(if (isPhone) 12 else 20), dp(if (isPhone) 8 else 14), dp(if (isPhone) 12 else 20), dp(if (isPhone) 24 else 12))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("TV WIDGET LAB", 18f, cyan, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()), 15f, muted, true))
        root.addView(header)
        root.addView(text("${page.uppercase(Locale.getDefault())}  /  PERSONAL TV ENVIRONMENT", 10f, muted, true))

        val pages = listOf("Home", "Apps", "Monitor", "Network", "Everyday", "Controls", "AI", "Widgets", "Profiles", "Settings")
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        val bodyScroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        bodyScroll.addView(content)

        if (!isPhone) {
            val sidebar = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(12), dp(9), dp(12))
                background = roundedBackground(surface, 20)
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            }
            sidebar.addView(text("NAVIGATION", 10f, muted, true))
            val sideButtons = mutableListOf<Button>()
            pages.forEach { p ->
                val b = Button(this).apply {
                    tag = p; id = View.generateViewId(); text = when(p) {
                        "Home" -> "⌂   Home"; "Apps" -> "▣   Apps"; "Monitor" -> "◉   Monitor"; "Network" -> "⌁   Network"
                        "Everyday" -> "◷   Everyday"; "Controls" -> "⚙   Controls"; "AI" -> "✦   AI Agent"; "Widgets" -> "▦   Widgets"
                        "Profiles" -> "◉   Profiles"; else -> "⚙   Settings"
                    }
                    gravity = Gravity.CENTER_VERTICAL; isAllCaps = false; textSize = 12f
                    setTextColor(if (p == page) cyan else Color.WHITE)
                    background = roundedBackground(if (p == page) Color.rgb(24, 67, 83) else Color.TRANSPARENT, 12)
                    isFocusable = true; isFocusableInTouchMode = true; minHeight = dp(44)
                    setOnFocusChangeListener { v, focused ->
                        v.background = roundedBackground(if (focused) Color.rgb(0, 92, 112) else if (p == page) Color.rgb(24, 67, 83) else Color.TRANSPARENT, 12)
                        v.scaleX = if (focused) 1.025f else 1f; v.scaleY = if (focused) 1.025f else 1f
                    }
                    setOnClickListener { showPage(p) }
                }
                sideButtons.add(b)
                sidebar.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(3) })
            }
            sideButtons.forEachIndexed { i, b ->
                b.nextFocusUpId = sideButtons[(i - 1 + sideButtons.size) % sideButtons.size].id
                b.nextFocusDownId = sideButtons[(i + 1) % sideButtons.size].id
            }
            body.addView(sidebar, LinearLayout.LayoutParams(dp(158), ViewGroup.LayoutParams.MATCH_PARENT).apply { marginEnd = dp(12) })
            body.addView(bodyScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            if (page == "Home") {
                val agentPanel = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = roundedBackground(surface, 20)
                }
                agentPanel.addView(text("✦  AI AGENT", 14f, cyan, true))
                agentPanel.addView(text("Personal assistant", 12f, muted))
                agentPanel.addView(text("Connection status", 11f, muted, true))
                agentPanel.addView(text("Backend not verified", 13f, Color.WHITE, true))
                agentPanel.addView(text("Your Agent workspace will provide conversations, system insights, tasks and discovery.", 12f, muted))
                agentPanel.addView(button("Open AI Workspace") { showPage("AI") })
                agentPanel.addView(text("QUICK ACTIONS", 10f, cyan, true))
                agentPanel.addView(button("Ask the Agent") { showPage("AI") })
                agentPanel.addView(button("System report") { showPage("Monitor") })
                body.addView(agentPanel, LinearLayout.LayoutParams(dp(218), ViewGroup.LayoutParams.MATCH_PARENT).apply { marginStart = dp(12) })
            }
        } else {
            body.addView(bodyScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (isPhone) {
            val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = false }
            val navButtons = mutableListOf<Button>()
            pages.forEach { p ->
                val b = Button(this).apply {
                    tag = p; id = View.generateViewId()
                    text = when (p) { "Everyday" -> "Daily"; "Controls" -> "Control"; "Profiles" -> "Profile"; else -> p }
                    isAllCaps = false; textSize = 10f; gravity = Gravity.CENTER
                    setTextColor(if (p == page) cyan else Color.WHITE)
                    background = roundedBackground(if (p == page) Color.rgb(24, 67, 83) else surface, 12)
                    isFocusable = true; isFocusableInTouchMode = true; minHeight = dp(44); minWidth = dp(66)
                    setOnClickListener { showPage(p) }
                }
                navButtons.add(b); nav.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { marginEnd = dp(4) })
            }
            val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(nav) }
            root.addView(navScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
            navButtons.firstOrNull { it.tag == page }?.requestFocus()
        }
        setContentView(root)
        when (page) { "Home" -> renderHome(); "Apps" -> renderApps(); "Monitor" -> renderMonitor(); "Network" -> renderNetwork(); "Everyday" -> renderEveryday(); "Controls" -> renderControls(); "AI" -> renderAI(); "Widgets" -> renderWidgets(); "Profiles" -> renderProfiles(); "Settings" -> renderSettings() }
        if (!isPhone) root.findViewWithTag<View>(page)?.requestFocus()
        if (activityResumed && page == "Everyday") handler.post(ticker)
    }
    private fun widgetEnabled(name: String): Boolean {
        val key = "widget_${name.lowercase(Locale.ROOT).replace(" ", "_")}"
        return prefs.getBoolean(key, true)
    }
    private fun renderHome() {
        content.addView(text("COMMAND CENTRE  /  YOUR TV AT A GLANCE", 12f, cyan, true))
        content.addView(text("Welcome back.", if (isPhone) 27f else 32f, Color.WHITE, true))
        if (widgetEnabled("Date")) {
            content.addView(text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()), 14f, muted))
        }

        val ram = ramUsage()
        val storage = storageUsage()
        val showRam = widgetEnabled("RAM")
        val showStorage = widgetEnabled("Storage")
        val showNetwork = widgetEnabled("Network")
        val showClock = widgetEnabled("Clock")
        val showStopwatch = widgetEnabled("Stopwatch")
        val showShortcuts = widgetEnabled("Quick shortcuts")

        if (showRam || showStorage) {
            content.addView(text("SYSTEM OVERVIEW", 12f, cyan, true))
            val metrics = LinearLayout(this).apply {
                orientation = if (isPhone || (showRam && showStorage && prefs.getString("widget_size", "Medium") == "Large")) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            }
            if (showRam) metrics.addView(meterCard("RAM", ram.first, "Live system memory"), if (metrics.orientation == LinearLayout.HORIZONTAL) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) else LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (showStorage) metrics.addView(meterCard("STORAGE", storage.first, "Internal data partition"), if (metrics.orientation == LinearLayout.HORIZONTAL) LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) else LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            content.addView(metrics)
        }

        if (showClock || showStopwatch || showNetwork) {
            content.addView(text("SYSTEM SNAPSHOT", 12f, cyan, true))
            val snapshot = LinearLayout(this).apply { orientation = if (isPhone) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
            if (showClock) snapshot.addView(card("CLOCK", SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()), "Device local time"))
            if (showStopwatch) {
                val elapsed = stopwatchElapsed + if (stopwatchRunning) (System.currentTimeMillis() - stopwatchBase) else 0L
                val totalSeconds = elapsed / 1000L
                val timerText = String.format(Locale.getDefault(), "%02d:%02d:%02d", totalSeconds / 3600, (totalSeconds / 60) % 60, totalSeconds % 60)
                snapshot.addView(card("STOPWATCH", timerText, "Open Everyday for controls"))
            }
            if (showNetwork) {
                val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
                val active = cm.activeNetwork
                val caps = if (active != null) cm.getNetworkCapabilities(active) else null
                val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
                val transport = when {
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular"
                    else -> "Unknown"
                }
                snapshot.addView(card("NETWORK", if (connected) "Connected" else "Offline", transport))
            }
            content.addView(snapshot)
        }

        if (showRam || showStorage) {
            content.addView(text("SYSTEM ACTIVITY", 12f, cyan, true))
            content.addView(text("Current utilisation only. CPU percentage and device temperature are not displayed unless Android exposes reliable readings.", 12f, muted))
            val activity = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(15), dp(12), dp(15), dp(12))
                background = roundedBackground(surface2, 18)
            }
            fun addUsageBar(label: String, value: Int) {
                activity.addView(text("$label  ·  $value%", 12f, Color.WHITE, true))
                val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100
                    progress = value
                    progressTintList = android.content.res.ColorStateList.valueOf(accentFor(value))
                    progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(55, 180, 200, 220))
                }
                activity.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(9)).apply { topMargin = dp(5); bottomMargin = dp(12) })
            }
            if (showRam) addUsageBar("Memory utilisation", ram.first)
            if (showStorage) addUsageBar("Storage utilisation", storage.first)
            content.addView(activity)
        }

        content.addView(text("FAVOURITE APPS", 12f, cyan, true))
        val favouritePackages = prefs.getStringSet("favourite_apps", emptySet()) ?: emptySet()
        val favourites = queryLaunchableApps().filter { it.activityInfo.packageName in favouritePackages }.take(6)
        if (favourites.isEmpty()) content.addView(text("No favourites selected yet. Add favourites from the Apps section.", 12f, muted))
        favourites.forEach { info ->
            val pkg = info.activityInfo.packageName
            val label = info.loadLabel(packageManager).toString()
            content.addView(button("★  $label") {
                try { startActivity(packageManager.getLaunchIntentForPackage(pkg)) }
                catch (_: Exception) { Toast.makeText(this, "Unable to launch $label", Toast.LENGTH_SHORT).show() }
            })
        }
        if (showShortcuts) {
            content.addView(text("QUICK ACCESS", 12f, cyan, true))
            listOf("App Library" to "Apps", "System Monitor" to "Monitor", "Network Dashboard" to "Network", "Widget Gallery" to "Widgets").forEach { (label, target) ->
                content.addView(button(label) { showPage(target) })
            }
        }
        content.addView(text("GOOGLE TV", 12f, cyan, true))
        content.addView(text("TV Widget Lab remains a separate app. Your original Google TV launcher and installed apps are not replaced or disabled.", 12f, muted))
        content.addView(button("Open compact widget overlay") { openOverlay() })
        content.addView(button("Return to Google TV Home") { goToGoogleTvHome() })
    }
    private fun renderApps() {
        content.addView(text("Installed TV apps", 23f, Color.WHITE, true)); content.addView(text("Choose an app to launch. Only apps exposed by Android's launcher query are shown.", 13f, muted))
        val apps = queryLaunchableApps()
        apps.forEach { info ->
            val name = info.loadLabel(packageManager).toString(); val pkg = info.activityInfo.packageName
            val favs = prefs.getStringSet("favourite_apps", emptySet()) ?: emptySet()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(button("▣   $name") { try { startActivity(packageManager.getLaunchIntentForPackage(pkg)) } catch (_: Exception) { Toast.makeText(this, "Unable to launch $name", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button(if (pkg in favs) "★" else "☆") { val next = (prefs.getStringSet("favourite_apps", emptySet()) ?: emptySet()).toMutableSet(); if (!next.add(pkg)) next.remove(pkg); prefs.edit().putStringSet("favourite_apps", next).apply(); showPage("Apps") }, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
            content.addView(row)
        }
        if (apps.isEmpty()) content.addView(text("No launchable apps were returned by Android.", 14f, muted))
    }
    private fun renderMonitor() {
        content.addView(text("SYSTEM MONITOR", 24f, Color.WHITE, true))
        val ram = ramUsage(); val storage = storageUsage()
        recordSystemSample(ram.first, storage.first)
        if (isPhone) { content.addView(meterCard("RAM", ram.first, "System-wide memory estimate")); content.addView(meterCard("STORAGE", storage.first, "Internal data partition")) }
        else { val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; row.addView(meterCard("RAM", ram.first, "System-wide memory estimate"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); row.addView(meterCard("STORAGE", storage.first, "Internal data partition"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); content.addView(row) }
        content.addView(card("CPU", "Unavailable", "A reliable CPU percentage source is not exposed to this app on this build."))
        content.addView(card("TEMPERATURE", "Unavailable", "No verified temperature sensor reading is available."))
        content.addView(text("RECENT HISTORY  /  UP TO 24 MANUAL SAMPLES", 12f, cyan, true))
        val history = readSystemSamples()
        if (history.isEmpty()) {
            content.addView(text("No history yet. Refresh readings to record a local RAM and storage snapshot.", 12f, muted))
        } else {
            content.addView(card("RAM TREND", sparkline(history.map { it.second }), "Oldest → latest · utilisation %"))
            content.addView(card("STORAGE TREND", sparkline(history.map { it.third }), "Oldest → latest · utilisation %"))
            val latest = history.last()
            content.addView(text("Latest sample: ${SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(latest.first))}  ·  RAM ${latest.second}%  ·  Storage ${latest.third}%", 11f, muted))
        }
        content.addView(button("Refresh readings / record sample") { showPage("Monitor") })
        content.addView(button("Clear local system history") {
            AlertDialog.Builder(this).setTitle("Clear system history?").setMessage("This only clears TV Widget Lab's locally stored RAM and storage samples.").setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ -> prefs.edit().remove("system_samples").apply(); showPage("Monitor") }.show()
        })
        content.addView(button("Free RAM / manage apps") { renderCleanupScreen() })
        content.addView(text("History is sampled only when this page is opened or refreshed. TV Widget Lab does not continuously poll in the background.", 11f, muted))
    }
    private data class SystemSample(val timestamp: Long, val ram: Int, val storage: Int)
    private fun readSystemSamples(): List<SystemSample> = (prefs.getString("system_samples", "") ?: "").split(";").mapNotNull { item ->
        val parts = item.split(",")
        if (parts.size != 3) null else {
            val time = parts[0].toLongOrNull(); val r = parts[1].toIntOrNull(); val st = parts[2].toIntOrNull()
            if (time == null || r == null || st == null) null else SystemSample(time, r.coerceIn(0, 100), st.coerceIn(0, 100))
        }
    }.takeLast(24)
    private fun recordSystemSample(ram: Int, storage: Int) {
        val samples = readSystemSamples().toMutableList()
        val now = System.currentTimeMillis()
        val last = samples.lastOrNull()
        if (last == null || now - last.timestamp >= 60_000L || last.ram != ram || last.storage != storage) {
            samples.add(SystemSample(now, ram.coerceIn(0, 100), storage.coerceIn(0, 100)))
            prefs.edit().putString("system_samples", samples.takeLast(24).joinToString(";") { "${it.timestamp},${it.ram},${it.storage}" }).apply()
        }
    }
    private fun sparkline(values: List<Int>): String {
        if (values.isEmpty()) return "No samples"
        val levels = charArrayOf('▁','▂','▃','▄','▅','▆','▇','█')
        return values.takeLast(24).joinToString("") { value -> levels[((value.coerceIn(0, 100) * (levels.size - 1)) / 100)].toString() }
    }
    private fun renderNetwork() {
        content.addView(text("NETWORK", 24f, Color.WHITE, true))
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = cm.activeNetwork; val caps = if (active != null) cm.getNetworkCapabilities(active) else null
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val transport = when { caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular"; else -> "Unknown" }
        content.addView(card("Connection", if (connected) "Connected" else "Not connected", "Transport: $transport"))
        content.addView(text("Signal strength and SSID may be restricted by Android permissions or TV firmware. Unsupported values are not fabricated.", 13f, muted))
        content.addView(button("Open Android network settings") { openSettings(Settings.ACTION_WIFI_SETTINGS) })
    }
    private fun renderEveryday() {
        content.removeAllViews()
        everydayClock = text("--:--:--", 28f, Color.WHITE, true)
        stopwatchDisplay = text("00:00:00", 30f, cyan, true)
        content.addView(text("EVERYDAY", 24f, Color.WHITE, true))
        content.addView(text("CLOCK", 12f, cyan, true)); content.addView(everydayClock)
        content.addView(text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 13f, muted))
        content.addView(text("STOPWATCH", 12f, cyan, true)); content.addView(stopwatchDisplay)
        content.addView(text(if (stopwatchRunning) "Running" else "Paused", 12f, muted))
        content.addView(button(if (stopwatchRunning) "Pause" else "Start / Resume") { if (stopwatchRunning) { stopwatchElapsed += System.currentTimeMillis()-stopwatchBase; stopwatchRunning=false } else { stopwatchBase=System.currentTimeMillis(); stopwatchRunning=true }; saveStopwatch(); renderEveryday() })
        content.addView(button("Record lap") { val now = stopwatchElapsed + if (stopwatchRunning) System.currentTimeMillis()-stopwatchBase else 0L; stopwatchLaps.add(now); saveStopwatch(); renderEveryday() })
        content.addView(button("Reset stopwatch") { stopwatchRunning=false; stopwatchElapsed=0L; stopwatchLaps.clear(); saveStopwatch(); renderEveryday() })
        if (stopwatchLaps.isNotEmpty()) {
            content.addView(text("LAPS", 12f, cyan, true))
            stopwatchLaps.forEachIndexed { index, lap -> content.addView(text("Lap ${index+1}  ·  ${String.format(Locale.getDefault(), "%02d:%02d:%02d", lap/3600000, (lap/60000)%60, (lap/1000)%60)}", 14f, muted)) }
        }
        updateEverydayDisplay()
    }
    private fun updateEverydayDisplay() {
        everydayClock?.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val elapsed = stopwatchElapsed + if (stopwatchRunning) System.currentTimeMillis() - stopwatchBase else 0L
        stopwatchDisplay?.text = String.format(Locale.getDefault(), "%02d:%02d:%02d", elapsed/3600000, (elapsed/60000)%60, (elapsed/1000)%60)
    }
    private fun saveStopwatch() {
        val value = stopwatchElapsed + if (stopwatchRunning) System.currentTimeMillis()-stopwatchBase else 0L
        prefs.edit().putLong("stopwatch_elapsed", value).putString("stopwatch_laps", stopwatchLaps.joinToString(",")).apply()
    }
    private fun renderControls() {
        content.addView(text("TV CONTROLS", 24f, Color.WHITE, true))
        content.addView(button("Wi-Fi settings") { openSettings(Settings.ACTION_WIFI_SETTINGS) })
        content.addView(button("Display settings") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) })
        content.addView(button("Sound settings") { openSettings(Settings.ACTION_SOUND_SETTINGS) })
        content.addView(button("Bluetooth settings") { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) })
        content.addView(button("Volume up") { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) })
        content.addView(button("Volume down") { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) })
        content.addView(button("Manage apps / Free RAM") { renderCleanupScreen() })
        content.addView(button("Return to Google TV Home") { goToGoogleTvHome() })
        content.addView(text("TCL-specific picture modes and direct volume/brightness controls depend on APIs exposed by the firmware.", 12f, muted))
    }
    private fun renderAI() {
        content.addView(text("PERSONAL AI", 26f, Color.WHITE, true))
        val orb = text("◉", 62f, cyan, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        content.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100)))
        content.addView(text("TV WIDGET LAB INTELLIGENCE", 15f, cyan, true))
        content.addView(card("Assistant status", if (aiService.isConfigured()) "Connected configuration" else "Local assistant ready", if (aiService.isConfigured()) "Secure AI backend is configured for this TV." else "Local TV commands work now. Add your secure backend URL and access code for conversational AI."))
        val input = EditText(this).apply { hint = "Ask a question or say a command…"; setHintTextColor(muted); setTextColor(Color.WHITE); setBackgroundColor(surface2); isFocusable=true; minHeight=dp(54) }
        content.addView(input)
        content.addView(button("Send to assistant") { val q=input.text.toString().trim(); if(q.isNotEmpty()) handleAssistantPrompt(q) })
        content.addView(button("Use voice input") { startVoiceInput() })
        content.addView(button("Connect AI backend") { showAiConfiguration() })
        content.addView(text("LOCAL COMMANDS", 12f, cyan, true))
        listOf("Open apps", "Open monitor", "Open network", "Open controls", "Open Google TV", "Open Wi-Fi settings", "Open display settings", "Open sound settings", "Open overlay").forEach { command -> content.addView(button(command) { handleAssistantPrompt(command) }) }
        content.addView(text("Voice recognition depends on the TV's speech services and microphone support. The microphone is activated only when you press the voice button.", 12f, muted))
    }
    private fun handleAssistantPrompt(prompt: String) {
        val q = prompt.lowercase(Locale.getDefault())
        when {
            q.contains("open google tv") || q.contains("go home") || q == "home" -> { goToGoogleTvHome(); return }
            q.contains("open apps") || q.contains("app library") -> { showPage("Apps"); return }
            q.contains("open monitor") || q.contains("system monitor") -> { showPage("Monitor"); return }
            q.contains("open network") || q.contains("wifi status") -> { showPage("Network"); return }
            q.contains("open controls") || q.contains("tv controls") -> { showPage("Controls"); return }
            q.contains("open settings") -> { showPage("Settings"); return }
            q.contains("open overlay") || q.contains("compact widget") -> { openOverlay(); return }
            q.contains("wifi settings") -> { openSettings(Settings.ACTION_WIFI_SETTINGS); return }
            q.contains("display settings") -> { openSettings(Settings.ACTION_DISPLAY_SETTINGS); return }
            q.contains("sound settings") -> { openSettings(Settings.ACTION_SOUND_SETTINGS); return }
            q.contains("bluetooth settings") -> { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); return }
            q.contains("volume up") || q.contains("increase volume") -> { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return }
            q.contains("volume down") || q.contains("decrease volume") -> { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return }
            q.contains("gaming profile") -> { prefs.edit().putString("profile", "Gaming").apply(); showPage("Profiles"); return }
            q.contains("movie profile") || q.contains("movies profile") -> { prefs.edit().putString("profile", "Movies").apply(); showPage("Profiles"); return }
            q.contains("night mode") -> { prefs.edit().putString("profile", "Night Mode").putBoolean("glass", false).apply(); showPage("Profiles"); return }
            q.contains("daily use profile") -> { prefs.edit().putString("profile", "Daily Use").apply(); showPage("Profiles"); return }
        }
        if (q.startsWith("open ")) {
            val requested = q.removePrefix("open ").trim()
            val match = queryLaunchableApps().firstOrNull { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()).contains(requested) }
            if (match != null) {
                try { startActivity(packageManager.getLaunchIntentForPackage(match.activityInfo.packageName)); return }
                catch (_: Exception) { Toast.makeText(this, "Unable to launch that app.", Toast.LENGTH_SHORT).show(); return }
            }
        }
        if (!aiService.isConfigured()) {
            AlertDialog.Builder(this).setTitle("AI provider not configured")
                .setMessage("Local commands are available. For conversational answers, configure your secure TV Widget Lab backend URL and access code. The OpenAI API key stays on the backend, not in this app.")
                .setPositiveButton("Configure") { _, _ -> showAiConfiguration() }.setNegativeButton("Close", null).show()
            return
        }
        Toast.makeText(this, "Assistant is thinking…", Toast.LENGTH_SHORT).show()
        aiExecutor.execute {
            try {
                val answer = aiService.ask(prompt)
                runOnUiThread { AlertDialog.Builder(this).setTitle("TV Widget Lab AI").setMessage(answer).setPositiveButton("Speak") { _, _ -> tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "tvlab-answer") }.setNegativeButton("Close", null).show() }
            } catch (e: Exception) {
                runOnUiThread { AlertDialog.Builder(this).setTitle("Assistant unavailable").setMessage(e.message ?: "The AI request failed.").setPositiveButton("OK", null).show() }
            }
        }
    }
    private fun showAiConfiguration() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val endpoint = EditText(this).apply { setText(aiService.endpoint()); hint = "Cloudflare Worker HTTPS URL"; setTextColor(Color.WHITE); setHintTextColor(muted); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI }
        val code = EditText(this).apply { hint = "TV Widget Lab access code"; setTextColor(Color.WHITE); setHintTextColor(muted); inputType = 129 }
        box.addView(endpoint); box.addView(code)
        AlertDialog.Builder(this).setTitle("Connect secure AI backend").setView(box)
            .setMessage("Enter the HTTPS URL of your deployed backend and its access code. Never enter your OpenAI API key here.")
            .setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                try {
                    aiService.saveConfiguration(endpoint.text.toString(), code.text.toString())
                    Toast.makeText(this, "AI backend settings saved", Toast.LENGTH_SHORT).show()
                    showPage("AI")
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: "Unable to save backend settings", Toast.LENGTH_LONG).show()
                }
            }.show()
    }
    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this, "Speech recognition is unavailable on this TV.", Toast.LENGTH_LONG).show(); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()) }
        try { startActivityForResult(intent, 4102) } catch (_: ActivityNotFoundException) { Toast.makeText(this, "No voice input activity is installed.", Toast.LENGTH_LONG).show() }
    }
    @Deprecated("Deprecated by Android, retained for broad TV compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4102 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) handleAssistantPrompt(spoken)
        }
    }
    private fun goToGoogleTvHome() {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { Toast.makeText(this, "Google TV Home could not be opened by Android.", Toast.LENGTH_SHORT).show() }
    }
    private fun renderWidgets() {
        content.addView(text("WIDGET GALLERY / EDIT MODE", 23f, Color.WHITE, true))
        content.addView(text("Choose which dashboard cards are visible. Changes are saved on this TV.", 13f, muted))
        val widgets = listOf("RAM", "Storage", "Clock", "Date", "Network", "Stopwatch", "Quick shortcuts")
        widgets.forEach { item ->
            val key = "widget_${item.lowercase().replace(" ", "_")}"
            val enabled = prefs.getBoolean(key, true)
            content.addView(button("${if (enabled) "✓" else "○"}   $item") { prefs.edit().putBoolean(key, !enabled).apply(); showPage("Widgets") })
        }
        val size = prefs.getString("widget_size", "Medium") ?: "Medium"
        content.addView(button("Widget size: $size (change)") { val choices = arrayOf("Small", "Medium", "Large"); AlertDialog.Builder(this).setTitle("Widget size").setItems(choices) { _, i -> prefs.edit().putString("widget_size", choices[i]).apply(); showPage("Widgets") }.show() })
        content.addView(button("Restore default widget selection") { AlertDialog.Builder(this).setMessage("Restore the default widget selection?").setNegativeButton("Cancel", null).setPositiveButton("Restore") { _, _ -> widgets.forEach { prefs.edit().remove("widget_${it.lowercase().replace(" ", "_")}").apply() }; showPage("Widgets") }.show() })
        content.addView(text("Visibility changes now control which supported cards appear on the Home dashboard. Large layout stacks the two system meters vertically. Freeform drag-and-drop positioning and per-widget styling are not enabled yet.", 12f, muted))
    }
    private fun renderProfiles() {
        content.addView(text("PERSONAL PROFILES", 23f, Color.WHITE, true))
        val profiles = listOf("Gaming", "Movies", "Daily Use", "Night Mode")
        val active = prefs.getString("profile", "Daily Use") ?: "Daily Use"
        content.addView(card("Active profile", active, "Profile selection is stored locally."))
        profiles.forEach { profile -> content.addView(button("${if (profile == active) "✓  " else ""}$profile") { prefs.edit().putString("profile", profile).apply(); if (profile == "Night Mode") prefs.edit().putBoolean("glass", false).apply() else prefs.edit().putBoolean("glass", true).apply(); showPage("Profiles") }) }
        content.addView(text("Automatic app-based profile switching and profile import/export require additional device-side testing and are not active yet.", 12f, muted))
    }
    private fun renderSettings() {
        content.addView(text("SETTINGS & PERSONALISATION", 23f, Color.WHITE, true))
        val glass = prefs.getBoolean("glass", true)
        content.addView(button("Appearance: ${if (glass) "Glass" else "Solid Black"} (switch)") { prefs.edit().putBoolean("glass", !glass).apply(); showPage("Settings") })
        content.addView(text(if (glass) "Scenic frosted-glass look with translucent surfaces." else "Opaque black surfaces with no transparency or wallpaper.", 12f, muted))
        if (glass) {
            content.addView(text("GLASS TRANSPARENCY", 12f, cyan, true))
            val opacityLabel = text("Surface opacity: $glassOpacity%", 12f, muted)
            content.addView(opacityLabel)
            val opacity = SeekBar(this).apply { max = 50; progress = glassOpacity - 35; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) { val value = progress + 35; prefs.edit().putInt("glass_opacity", value).apply(); opacityLabel.text = "Surface opacity: $value%" } }; override fun onStartTrackingTouch(seekBar: SeekBar?) {}; override fun onStopTrackingTouch(seekBar: SeekBar?) { showPage("Settings") } }) }
            content.addView(opacity, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        }
        val profile = prefs.getString("profile", "Daily Use") ?: "Daily Use"
        content.addView(button("Profile: $profile (change)") { val choices=arrayOf("Gaming","Movies","Daily Use","Night Mode"); AlertDialog.Builder(this).setTitle("Choose profile").setItems(choices) { _, which -> prefs.edit().putString("profile",choices[which]).apply(); showPage("Settings") }.show() })
        content.addView(button("Open Widget Gallery / Edit Mode") { showPage("Widgets") })
        content.addView(button("Manage Profiles") { showPage("Profiles") })
        content.addView(button("Allow display over other apps") { if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else Toast.makeText(this,"Permission already granted",Toast.LENGTH_SHORT).show() })
        content.addView(button("Restore app defaults") { AlertDialog.Builder(this).setTitle("Restore defaults?").setMessage("Only TV Widget Lab preferences will be reset. Google TV and installed apps will not be changed.").setNegativeButton("Cancel",null).setPositiveButton("Reset") { _, _ -> prefs.edit().clear().apply(); showPage("Settings") }.show() })
        content.addView(text("Some advanced profile automation, launcher integration, AI connectivity and TCL-specific controls require device testing or additional services.", 12f, muted))
    }
    private fun openOverlay() {
        val tv = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || packageManager.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
        if (!tv) { AlertDialog.Builder(this).setTitle("TV-only overlay").setMessage("The floating overlay is disabled on phones to protect the phone interface.").setPositiveButton("OK",null).show(); return }
        if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return }
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW)); Toast.makeText(this,"Compact overlay opened",Toast.LENGTH_SHORT).show()
    }
    private fun openSettings(action: String) { try { startActivity(Intent(action)) } catch (_: Exception) { Toast.makeText(this,"This settings page is unavailable on this TV.",Toast.LENGTH_SHORT).show() } }
    private fun ramUsage(): Pair<Int, String> { val m = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m); val pct = if (m.totalMem > 0) (((m.totalMem - m.availMem).toDouble() / m.totalMem) * 100).toInt().coerceIn(0,100) else 0; return pct to "$pct%" }
    private fun storageUsage(): Pair<Int, String> { val st = StatFs(android.os.Environment.getDataDirectory().absolutePath); val pct = if (st.totalBytes > 0) (((st.totalBytes - st.availableBytes).toDouble() / st.totalBytes) * 100).toInt().coerceIn(0,100) else 0; return pct to "$pct%" }
    private fun meterCard(title: String, value: Int, detail: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(15), dp(13), dp(15), dp(13)); background = roundedBackground(surface2, 20)
        alpha = 0f; translationY = dp(7).toFloat(); post { animate().alpha(1f).translationY(0f).setDuration(190L).start() }
        val ring = MetricRingView(this@MainActivity).apply { percent = value; ringColor = accentFor(value) }
        addView(ring, LinearLayout.LayoutParams(dp(if (isPhone) 104 else 118), dp(if (isPhone) 104 else 118)).apply { gravity = Gravity.CENTER })
        addView(text(title, 12f, cyan, true)); addView(text(detail, 11f, muted))
        val bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = value; progressTintList = android.content.res.ColorStateList.valueOf(accentFor(value)); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(55,180,200,220)) }
        addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)).apply { topMargin = dp(9) })
        val lp = LinearLayout.LayoutParams(if (isPhone) ViewGroup.LayoutParams.MATCH_PARENT else 0, ViewGroup.LayoutParams.WRAP_CONTENT, if (isPhone) 0f else 1f); lp.setMargins(dp(4), dp(5), dp(4), dp(7)); layoutParams = lp
    }
    private fun ramPercent(): String { val m=ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m); return if(m.totalMem>0) "${(((m.totalMem-m.availMem).toDouble()/m.totalMem)*100).toInt()}%" else "Unavailable" }
    private fun storagePercent(): String { val s=StatFs(android.os.Environment.getDataDirectory().absolutePath); return if(s.totalBytes>0) "${((s.totalBytes-s.availableBytes).toDouble()/s.totalBytes*100).toInt()}%" else "Unavailable" }
    @Suppress("DEPRECATION") private fun queryLaunchableApps(): List<android.content.pm.ResolveInfo> { val i=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); val tv=packageManager.queryIntentActivities(i,0); return (if(tv.isNotEmpty()) tv else packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0)).sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) } }
    private fun renderCleanupScreen() {
        val apps = queryLaunchableApps().filter { it.activityInfo.packageName != packageName }
        if (apps.isEmpty()) {
            AlertDialog.Builder(this).setTitle("App management")
                .setMessage("No launchable apps were returned. Use Android Settings → Apps to manage applications.")
                .setPositiveButton("OK", null).show()
            return
        }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose an app to manage")
            .setItems(labels) { _, which ->
                val pkg = apps[which].activityInfo.packageName
                AlertDialog.Builder(this).setTitle("Manage ${labels[which]}?")
                    .setMessage("Android will open the app information page. If available, you can choose Force stop there. TV Widget Lab cannot silently stop other apps. Do not stop Google TV, the launcher or essential system apps.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open app info") { _, _ ->
                        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
                        catch (_: Exception) { Toast.makeText(this, "Unable to open app info", Toast.LENGTH_SHORT).show() }
                    }.show()
            }.show()
    }
}
