# TV Widget Lab — starter project

A first Android TV app prototype for a customizable widget gallery and floating performance overlay. This revision fixes literal \n text appearing in the main screen and overlay by using real Kotlin newline escapes.

## Current prototype features
- TV-friendly main screen
- Request for Android's "Display over other apps" permission
- Start/stop floating overlay
- Overlay displays clock, date, RAM estimate, and internal storage usage
- Keeps the existing Google TV launcher unchanged
- Basic persistent overlay preference is not yet implemented

## Important limitations
- This is a starter project, not a tested or production-ready app.
- It has not been compiled against your specific TCL TV or tested on your firmware.
- Floating overlays may be blocked or restricted by some Google TV builds or protected video apps.
- RAM figures are system memory figures, not exact per-app usage.
- CPU temperature, CPU utilization, live network throughput, Wi-Fi SSID, app shortcuts, widget editor, and saved layouts are planned features, not implemented in this first prototype.
- Overlay permission must be granted manually in TV settings when the system offers it.
- Do not use this app to disable or remove system apps.

## Build on your phone using GitHub Actions
1. Create a GitHub repository named `TVWidgetLab`.
2. Upload the contents of this folder to the repository root.
3. Open the repository's **Actions** tab and run **Build TV Widget Lab APK**.
4. Download the `tv-widget-lab-debug-apk` artifact from the completed workflow.
5. Extract the artifact ZIP on your phone to get `app-debug.apk`.
6. Transfer the APK to the TV using a trusted file-transfer method and install it if sideloading is allowed.

The workflow uses a cloud runner; Android Studio is not required on your phone.

## Local build
If you have a computer with JDK 17 and Android SDK installed, run:
`gradle assembleDebug`

## Updating later
Keep the same Android application ID and signing identity for release updates. Debug APKs from the same project can usually update earlier debug builds signed with the same debug key, but a production release needs a securely backed-up release signing key.
