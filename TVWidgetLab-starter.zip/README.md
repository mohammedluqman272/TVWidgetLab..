# TV Widget Lab — Compact Overlay + D-pad Test

This is a test build using application ID `com.tvwidgetlab.test`. It is intended to remain separate from the original `com.tvwidgetlab` installation.

## Included in this test
- Compact single-row overlay at the top-right of the screen.
- Clock and date, RAM usage, and app-accessible storage usage.
- CLEAN opens the app picker and then Android App info for the selected app.
- Refresh button updates available readings.
- Close button hides the overlay.
- Readings update every five seconds while the overlay is open.
- Overlay window is focusable and its buttons show a visible focus highlight for D-pad testing.
- The normal Google TV launcher is not replaced or modified.

## Important limitations
- This is an Android overlay, not a native Google TV launcher widget.
- A normal third-party app cannot silently force-stop other apps; Android retains control of that action.
- Storage is measured from the app's accessible files directory, not all TV internal storage.
- CPU usage, CPU temperature, Wi-Fi details, network throughput, widget gallery/customization, and drag-to-move are not included in this test.
- D-pad focus behavior must be tested on the actual TCL TV because vendor firmware can vary.

## Build and installation
1. Upload the contents of this source project to the repository root (keep `.github/workflows/build.yml`).
2. Run the GitHub Actions workflow and wait for a green successful build.
3. Download `tv-widget-lab-debug-apk` and install `app-debug.apk` as a separate test app.
4. Keep the existing working app installed until this test build has been verified.
5. Keep Play Protect enabled. Do not install if Android reports a specific harmful-app warning; share the warning for review.
