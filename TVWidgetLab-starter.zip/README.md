# TV Widget Lab — Dashboard UI Test

This is a separate test build (`com.tvwidgetlab.test`) so it can be installed alongside an existing `com.tvwidgetlab` app when Android permits it.

## Current prototype
- Manually opened overlay dashboard; it does not intentionally start on every app launch.
- Dark compact dashboard with separate time/date, RAM, and app-accessible storage cards.
- One refresh button updates the available readings together.
- One close button hides the entire board without removing the app or its saved settings.
- Clean Memory opens a list of launchable apps and then the selected app's Android App Info page. The user must use Android's own Force stop control if available.
- Dashboard readings update automatically every five seconds while the overlay is open.

## Important limitations
- A normal third-party app cannot silently force-stop other apps. Android/Google TV retains control of that action.
- Storage shown is app-accessible storage, not total physical TV storage.
- The board is an overlay, not a native Google TV launcher element. Launcher integration is not provided by the normal Android app APIs.
- CPU temperature, CPU usage, network throughput, Wi-Fi details, and editable widget placement/presets are not implemented in this prototype.

## Build
Use the repository's GitHub Actions workflow. This source ZIP has not been compiled in this environment; inspect the Actions result before installing. Keep Play Protect enabled.
