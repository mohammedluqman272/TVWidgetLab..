package com.tvwidgetlab

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlayCode = 42

    companion object {
        const val EXTRA_CLEAN_MEMORY = "com.tvwidgetlab.extra.CLEAN_MEMORY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.getBooleanExtra(EXTRA_CLEAN_MEMORY, false)) renderCleanupScreen() else render()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) {
            statusText.text = if (Settings.canDrawOverlays(this)) {
                "Overlay permission: granted"
            } else {
                "Overlay permission: not granted"
            }
        }
    }

    private lateinit var statusText: TextView

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 32, 48, 32)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "TV Widget Lab"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 12)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Open your widget board only when you need it"
            textSize = 17f
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, 0, 0, 22)
        }
        root.addView(subtitle)

        val galleryTitle = TextView(this).apply {
            text = "READY-MADE WIDGETS"
            textSize = 14f
            setTextColor(0xFF68D9A3.toInt())
            setPadding(0, 0, 0, 8)
        }
        root.addView(galleryTitle)

        val widgetList = TextView(this).apply {
            text = "✓ Digital clock    ✓ Date and day\n✓ RAM monitor       ✓ Storage monitor"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 22)
        }
        root.addView(widgetList)

        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFFFD27D.toInt())
            text = if (Settings.canDrawOverlays(this@MainActivity)) {
                "Overlay permission: granted"
            } else {
                "Overlay permission: not granted"
            }
            setPadding(0, 0, 0, 12)
        }
        root.addView(statusText)

        root.addView(makeButton("1. Allow the board to appear over other apps") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission is already granted", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, requestOverlayCode)
            }
        })

        root.addView(makeButton("2. Open widget board") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
                Toast.makeText(this, "Widget board opened", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(makeButton("Clean Memory — choose an app") {
            renderCleanupScreen()
        })

        root.addView(makeButton("Hide widget board") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Widget board hidden; layout is preserved", Toast.LENGTH_SHORT).show()
        })

        val note = TextView(this).apply {
            text = "\nPrototype: open the board manually; it stays hidden otherwise. Refresh updates readings, and × hides the whole board. Clean Memory lists launchable apps and opens Android's app-info page for the one you choose. Android does not let a normal app force-stop other apps directly, so you must confirm Force stop in system settings. Google TV launcher stays unchanged."
            textSize = 14f
            setTextColor(0xFFB8C7D9.toInt())
        }
        root.addView(note)
        setContentView(root)
    }


    private fun renderCleanupScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Clean Memory"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Choose an app to manage. Android requires you to confirm Force stop in the next screen; TV Widget Lab cannot close other apps silently. Avoid stopping Google TV, launcher, or system apps."
            textSize = 16f
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, 0, 0, 18)
        })

        val apps = queryLaunchableApps()
        if (apps.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "No launchable apps could be listed on this device. Open Android Settings → Apps to manage apps manually."
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
            })
        } else {
            for (resolveInfo in apps) {
                val appName = resolveInfo.loadLabel(packageManager).toString()
                val appPackage = resolveInfo.activityInfo.packageName
                root.addView(makeButton(appName) {
                    AlertDialog.Builder(this)
                        .setTitle("Manage $appName?")
                        .setMessage("Android will open this app's system info page. If available, tap Force stop there to close it.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Open app settings") { _, _ ->
                            try {
                                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$appPackage")))
                            } catch (_: Exception) {
                                Toast.makeText(this, "Could not open app settings", Toast.LENGTH_LONG).show()
                            }
                        }
                        .show()
                })
            }
        }
        root.addView(makeButton("Back to dashboard") { render() })
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun queryLaunchableApps(): List<android.content.pm.ResolveInfo> {
        val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val tvApps = packageManager.queryIntentActivities(tvIntent, 0)
        if (tvApps.isNotEmpty()) return tvApps.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val phoneIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(phoneIntent, 0)
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 8 }
            isFocusable = true
            isFocusableInTouchMode = true
        }
    }
}
