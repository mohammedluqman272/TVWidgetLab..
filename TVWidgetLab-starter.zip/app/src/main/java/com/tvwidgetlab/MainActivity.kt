package com.tvwidgetlab

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlayCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) {
            statusText.text = if (Settings.canDrawOverlays(this)) {
                "Overlay permission: granted"
            } else {
                "Overlay permission: not granted"
            }
        }
    }

    private lateinit var statusText: TextView

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 32, 48, 32)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "TV Widget Lab"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 12)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Your customizable floating-widget workspace"
            textSize = 17f
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, 0, 0, 22)
        }
        root.addView(subtitle)

        val galleryTitle = TextView(this).apply {
            text = "READY-MADE WIDGETS"
            textSize = 14f
            setTextColor(0xFF68D9A3.toInt())
            setPadding(0, 0, 0, 8)
        }
        root.addView(galleryTitle)

        val widgetList = TextView(this).apply {
            text = "✓ Digital clock    ✓ Date and day\n✓ RAM monitor       ✓ Storage monitor"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 22)
        }
        root.addView(widgetList)

        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFFFD27D.toInt())
            text = if (Settings.canDrawOverlays(this@MainActivity)) {
                "Overlay permission: granted"
            } else {
                "Overlay permission: not granted"
            }
            setPadding(0, 0, 0, 12)
        }
        root.addView(statusText)

        root.addView(makeButton("1. Grant overlay permission") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission is already granted", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, requestOverlayCode)
            }
        })

        root.addView(makeButton("2. Add widgets to screen") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
                Toast.makeText(this, "Overlay started", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(makeButton("Hide all widgets") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Overlay hidden", Toast.LENGTH_SHORT).show()
        })

        val note = TextView(this).apply {
            text = "Prototype note: this first build includes clock, date, RAM and storage. More widgets and visual controls can be added in later versions."
            textSize = 14f
            setTextColor(0xFFB8C7D9.toInt())
        }
        root.addView(note)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 8 }
            isFocusable = true
            isFocusableInTouchMode = true
        }
    }
}
