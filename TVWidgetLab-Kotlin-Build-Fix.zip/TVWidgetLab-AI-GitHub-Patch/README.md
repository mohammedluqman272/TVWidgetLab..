# TV Widget Lab — TV Edition (expanded source)

TV Widget Lab is a separate Android TV app. It does **not** replace, disable, or modify Google TV or installed apps. The system Home button remains the reliable route back to the original launcher; use the app list to reopen TV Widget Lab.

## Implemented in this source update
- TV dashboard with Home, Apps, Monitor, Network, Everyday, Controls, AI, Widgets, Profiles and Settings pages.
- D-pad-friendly navigation and focus feedback.
- Installed app discovery and launching; locally saved favourite apps and dashboard favourites.
- RAM and internal data-partition storage readings using Android APIs.
- Local system history: up to 24 RAM/storage snapshots, captured only when the System Monitor page is opened/refreshed; simple trend sparklines and a user-controlled clear-history action. No continuous background sampling.
- Network connection and transport status where Android exposes it.
- Clock and stopwatch with lap recording and local persistence.
- Android settings shortcuts for Wi-Fi, display, sound and Bluetooth.
- Volume up/down actions using Android AudioManager.
- Safe app-management flow that opens Android App Info; no silent force-stop.
- Compact overlay and expandable panel from the supplied source.
- Widget visibility editor and size preference; Home dashboard now honours RAM, Storage, Clock, Date, Network, Stopwatch and Quick shortcuts visibility. Large system-meter layout stacks RAM and Storage vertically; four locally saved profiles.
- Local assistant commands for navigation, app launching, profiles, volume and supported settings shortcuts.
- Optional voice input via the installed Android speech-recognition activity and spoken AI replies via Android Text-to-Speech. Voice availability depends on TV firmware and speech services.
- Optional secure AI backend connection through a Cloudflare Worker. The OpenAI API key is held as a server-side Worker secret and is not entered into the TV app or stored in the APK.
- GitHub Actions workflow to build a debug APK.

## Still limited / not claimed as complete
- **Google TV home-screen slider:** stock Google TV generally does not expose an API for third-party apps to insert a persistent home-only slider. This app includes a return-to-Google-TV action and remains a separate app. A native launcher slider needs verified TCL launcher support; no launcher replacement, accessibility interception or risky overlay-on-home workaround is used.
- **AI provider:** conversational AI requires a deployed Cloudflare Worker, GitHub Actions secrets, an OpenAI API project and a TV-side backend access code. The Worker defaults to `gpt-4o-mini`; select only a model enabled for the API project. Provider charges and terms may apply. Local commands work without the AI provider. Voice recognition is device-dependent and is activated only by the user. See `README-AI-SETUP.md`.
- **TCL-specific controls:** picture modes, direct brightness, and vendor-specific device controls are not assumed to exist. Settings shortcuts and volume changes are provided where Android exposes them.
- **CPU and temperature:** no fake values are shown. These remain unavailable unless the TV exposes reliable readings to ordinary apps.
- **Advanced widget editor:** widget visibility is applied to supported Home dashboard cards; the Large setting stacks the RAM and Storage meters vertically. Freeform drag-and-drop positioning, arbitrary per-widget styling, per-widget placement and fully custom user-created widgets are not implemented yet.
- **Profiles:** Gaming, Movies, Daily Use and Night Mode are saved local profile choices. Automatic app-based switching and import/export are not implemented yet.
- **Overlay:** requires Android's Display over other apps permission. D-pad focus, Home-key handling and service behaviour vary by firmware and must be tested on the target TCL TV.
- **Build/device verification:** source has not been compiled or tested on the user's TCL television in this environment. Run the GitHub Actions workflow and test the resulting APK on the TV before treating it as a release.

## Build
Push the project contents to the repository's `main` branch or run the workflow manually:
GitHub → Actions → Build TV Widget Lab APK → Run workflow.
Download the `tv-widget-lab-debug-apk` artifact from a successful run.

## Package identity
Application ID remains `com.tvwidgetlab.test` to preserve compatibility with the earlier test installation. Do not rename the package unless intentionally migrating the installed app.

## Safety and privacy
- No root, device-admin, accessibility-service or launcher-replacement permission is requested.
- Google TV and installed apps are not disabled or removed.
- The app does not silently force-stop other apps.
- AI requests are sent only after the user configures the backend and submits a prompt. Prompts are forwarded to the configured AI provider through the Worker. The TV app stores the backend access code locally; it is not a replacement for server-side rate limits or account spending controls.

## Performance safeguards (revision)
- The Everyday clock/stopwatch ticker runs only while the Everyday page is visible and the activity is resumed; it is cancelled on page changes, pause, and destroy.
- The continuously pulsing AI orb animation has been removed to avoid an always-running animation loop.
- Compact overlay RAM/storage polling is reduced from every 5 seconds to every 30 seconds. Manual refresh remains available.
- These changes reduce background work; actual performance on the TCL TV still needs a cautious on-device test.


## Glass and Solid Black appearance update
- Glass mode uses a scenic night wallpaper, a dark readability scrim, and translucent surfaces.
- Glass surface opacity is adjustable in Settings.
- Solid Black remains fully opaque and hides the wallpaper.
- The wallpaper is softly pre-blurred for compatibility with Android TV 11 (API 30); live per-view backdrop blur is not available consistently on that OS version.
- Phone navigation reserves extra bottom space; TV layout remains landscape/remote oriented.
- RAM and storage indicators use green (<70%), amber (70–84%), and red (85%+) thresholds.

## Home Command Centre UI update

The TV layout now uses a persistent left navigation sidebar, a central Home command dashboard, and a right-side AI Agent panel on Home. The dashboard displays live RAM and storage meters, usage bars, network connectivity and the active local profile. It retains the existing scenic frosted-glass / solid-black background preference. The phone layout continues to use its separate compact navigation rather than the TV three-column layout.

The AI panel is a UI entry point only: it labels backend connectivity as unverified and does not imply that the planned cloud Agent features are already implemented. CPU percentage and temperature are not fabricated when Android does not expose reliable readings.

Build verification: source updated; an Android build has not been run in this environment because Gradle/Android SDK are not installed here. The GitHub Actions workflow now runs Android unit-test tasks and assembles the debug APK on pushes, pull requests and manual dispatch. A successful Actions run is still required to verify compilation and produce the APK.

## Dashboard profiles and widget sizing update

The TV dashboard now applies local profile presets from both the Profiles page and Settings:

- **Gaming** prioritises RAM, storage, network status and quick shortcuts.
- **Movies** prioritises clock, date, network status and quick shortcuts.
- **Daily Use** enables the full supported widget set.
- **Night Mode** enables core system/time widgets and switches to the solid dark appearance.

Widget size selection now changes the RAM/storage meter card footprint (Small, Medium, Large). These settings remain local to TV Widget Lab. Profiles do not change Android system settings, Google TV, or installed apps.

### GitHub Actions Kotlin compile fix
The system-history renderer now reads the named `SystemSample` properties (`timestamp`, `ram`, and `storage`) instead of treating the data class as a three-item tuple. This resolves the reported unresolved `first`, `second`, and `third` references in `MainActivity.kt`.
