package com.tvwidgetlab

import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var clockValue: TextView? = null
    private var dateValue: TextView? = null
    private var ramValue: TextView? = null
    private var ramDetail: TextView? = null
    private var storageValue: TextView? = null
    private var storageDetail: TextView? = null
    private var statusValue: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val formatter = DecimalFormat("0.0")

    private val updater = object : Runnable {
        override fun run() {
            refreshReadings()
            handler.postDelayed(this, 5000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                refreshReadings()
                return START_NOT_STICKY
            }
        }
        if (windowManager == null) windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (panel == null) createOverlay()
        handler.removeCallbacks(updater)
        refreshReadings()
        handler.postDelayed(updater, 5000L)
        return START_NOT_STICKY
    }

    private fun createOverlay() {
        val wm = windowManager ?: return

        // Compact, single-row status bar designed to leave most of the TV visible.
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(8), dp(7))
            setBackgroundColor(Color.rgb(14, 27, 40))
            // Allow Android TV's D-pad to move focus among the buttons.
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        val timeBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), 0, dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(dp(100), dp(48))
        }
        clockValue = TextView(this).apply {
            text = "--:--"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        dateValue = TextView(this).apply {
            text = "Loading date"
            textSize = 9f
            setTextColor(Color.rgb(184, 199, 217))
            maxLines = 1
        }
        timeBlock.addView(clockValue)
        timeBlock.addView(dateValue)
        outer.addView(timeBlock)
        outer.addView(separator())

        outer.addView(compactMetric("RAM", "--", "--") { value, detail ->
            ramValue = value
            ramDetail = detail
        }, LinearLayout.LayoutParams(dp(82), dp(48)))
        outer.addView(separator())
        outer.addView(compactMetric("STORAGE", "--", "--") { value, detail ->
            storageValue = value
            storageDetail = detail
        }, LinearLayout.LayoutParams(dp(94), dp(48)))
        outer.addView(separator())

        outer.addView(smallButton("CLEAN", false) {
            val intent = Intent(this@OverlayService, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_CLEAN_MEMORY, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }.apply { textSize = 10f; minHeight = dp(38) })
        outer.addView(smallButton("↻", false) {
            refreshReadings()
            statusValue?.text = "Updated"
        }.apply { textSize = 16f; minHeight = dp(38) })
        outer.addView(smallButton("×", false) { stopSelf() }.apply {
            textSize = 17f
            minHeight = dp(38)
        })

        statusValue = TextView(this).apply { text = "Updated"; visibility = View.GONE }
        panel = outer

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            // FLAG_NOT_FOCUSABLE prevented the TV remote's D-pad from reaching these buttons.
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(14)
            y = dp(14)
        }
        try {
            wm.addView(panel, params)
            // Give the overlay initial focus so the remote can operate it immediately.
            panel?.post {
                val firstFocusable = panel?.focusables(View.FOCUS_FORWARD)?.firstOrNull()
                firstFocusable?.requestFocus()
            }
        } catch (_: Exception) {
            panel = null
            stopSelf()
        }
    }

    private fun separator(): View = View(this).apply {
        setBackgroundColor(Color.rgb(56, 78, 96))
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(30)).apply {
            leftMargin = dp(3)
            rightMargin = dp(3)
        }
    }

    private fun compactMetric(
        label: String,
        initialValue: String,
        initialDetail: String,
        onCreated: (TextView, TextView) -> Unit
    ): View {
        val block = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, dp(4), 0)
        }
        block.addView(TextView(this).apply {
            text = label
            textSize = 9f
            setTextColor(Color.rgb(139, 233, 224))
        })
        val value = TextView(this).apply {
            text = initialValue
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        val detail = TextView(this).apply {
            text = initialDetail
            textSize = 8f
            setTextColor(Color.rgb(184, 199, 217))
            maxLines = 1
        }
        block.addView(value)
        block.addView(detail)
        onCreated(value, detail)
        return block
    }

    private fun makeCard(title: String, initialValue: String, type: String, onCreated: (TextView, TextView) -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            setBackgroundColor(Color.rgb(34, 49, 65))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(139, 233, 224))
        })
        val value = TextView(this).apply {
            text = initialValue
            textSize = if (type == "clock") 26f else 21f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(3), 0, dp(2))
        }
        card.addView(value)
        val detail = TextView(this).apply {
            text = if (type == "clock") "Loading date…" else "Loading details…"
            textSize = 12f
            setTextColor(Color.rgb(184, 199, 217))
        }
        card.addView(detail)
        onCreated(value, detail)
        return card
    }

    private fun smallButton(label: String, wide: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = if (wide) 12f else 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 72, 91))
            minHeight = dp(if (wide) 44 else 40)
            // Make remote focus unmistakable without relying on pointer hover.
            isFocusable = true
            isFocusableInTouchMode = true
            setOnFocusChangeListener { view, hasFocus ->
                view.setBackgroundColor(
                    if (hasFocus) Color.rgb(0, 150, 136) else Color.rgb(48, 72, 91)
                )
                view.scaleX = if (hasFocus) 1.04f else 1.0f
                view.scaleY = if (hasFocus) 1.04f else 1.0f
            }
            setPadding(dp(8), 0, dp(8), 0)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                if (wide) LinearLayout.LayoutParams.MATCH_PARENT else LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(if (wide) 44 else 40)
            ).apply { if (wide) topMargin = dp(8) else leftMargin = dp(6) }
        }
    }

    private fun refreshReadings() {
        val now = Date()
        val clockPattern = if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm a"
        clockValue?.text = SimpleDateFormat(clockPattern, Locale.getDefault()).format(now)
        dateValue?.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalMb = memoryInfo.totalMem / (1024.0 * 1024.0)
        val availableMb = memoryInfo.availMem / (1024.0 * 1024.0)
        val usedMb = (totalMb - availableMb).coerceAtLeast(0.0)
        val ramPercent = if (totalMb > 0) ((usedMb / totalMb) * 100).toInt() else 0
        ramValue?.text = "$ramPercent% used"
        ramDetail?.text = "${formatter.format(usedMb / 1024)} / ${formatter.format(totalMb / 1024)} GB"

        val stat = StatFs(filesDir.absolutePath)
        val totalStorage = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
        val freeStorage = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val usedStorage = (totalStorage - freeStorage).coerceAtLeast(0.0)
        val storagePercent = if (totalStorage > 0) (usedStorage / totalStorage * 100).toInt() else 0
        storageValue?.text = "$storagePercent% used"
        storageDetail?.text = "${formatter.format(usedStorage)} / ${formatter.format(totalStorage)} GB app"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(updater)
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panel = null
        clockValue = null
        dateValue = null
        ramValue = null
        ramDetail = null
        storageValue = null
        storageDetail = null
        statusValue = null
        windowManager = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW = "com.tvwidgetlab.action.SHOW"
        const val ACTION_HIDE = "com.tvwidgetlab.action.HIDE"
        const val ACTION_REFRESH = "com.tvwidgetlab.action.REFRESH"
    }
}
