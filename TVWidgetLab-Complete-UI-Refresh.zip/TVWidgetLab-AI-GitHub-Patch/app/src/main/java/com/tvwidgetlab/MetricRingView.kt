package com.tvwidgetlab

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Lightweight canvas ring; no animation loop or external chart dependency. */
class MetricRingView(context: Context) : View(context) {
    var percent: Int = 0
        set(value) { field = value.coerceIn(0, 100); invalidate() }
    var ringColor: Int = 0xFF2ED3A0.toInt()
        set(value) { field = value; invalidate() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0x334F6A80; strokeWidth = 12f }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 12f }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 27f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val radius = (minOf(width, height) / 2f) - 12f
        track.strokeWidth = radius * .19f; arc.strokeWidth = track.strokeWidth; arc.color = ringColor
        canvas.drawCircle(cx, cy, radius, track)
        canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), -90f, percent * 3.6f, false, arc)
        label.textSize = radius * .58f
        canvas.drawText("$percent%", cx, cy - (label.ascent() + label.descent()) / 2f, label)
    }
}
