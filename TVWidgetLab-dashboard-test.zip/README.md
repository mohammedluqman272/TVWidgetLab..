# TV Widget Lab Test Build

This is a separate test package (`com.tvwidgetlab.test`) intended to install alongside the existing TV Widget Lab app. It does not replace or remove the existing app.

## Current prototype features
- Manually open a single widget board from the app.
- One **Refresh** button refreshes the available readings immediately.
- One **×** button hides the entire board without clearing the layout.
- Clock/date and RAM readings.
- Storage display is limited to app-accessible storage and must not be interpreted as total TV storage.
- Readings refresh automatically every three seconds while the board is open.

## Important limitations
- The board is not permanently visible. It opens only when you request it from the app.
- Third-party apps cannot simply add a native Settings-style button to the existing Google TV launcher. Automatic detection of “no app is being used” and native launcher integration are not implemented.
- Overlay permission is required to show the board over other apps. Some TVs may restrict this.
- CPU usage, device temperature, Wi-Fi details, live network throughput, quick shortcuts, visual editor and saved appearance presets are not implemented in this prototype.
- This source ZIP has not been compiled or tested on the TV yet. Use GitHub Actions to build it, and keep Play Protect enabled. Do not bypass security warnings.

## Build
The repository workflow expects this project ZIP to be named `TVWidgetLab-starter.zip` at the repository root.
