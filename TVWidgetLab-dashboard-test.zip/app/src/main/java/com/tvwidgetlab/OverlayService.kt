package com.tvwidgetlab

import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.text.format.DateFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var content: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val formatter = DecimalFormat("0.0")

    private val updater = object : Runnable {
        override fun run() {
            content?.text = buildStatusText()
            handler.postDelayed(this, 3000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH) {
            content?.text = buildStatusText()
            return START_NOT_STICKY
        }
        if (windowManager == null) windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (panel == null) createOverlay()
        handler.removeCallbacks(updater)
        content?.text = buildStatusText()
        handler.postDelayed(updater, 3000L)
        return START_NOT_STICKY
    }

    private fun createOverlay() {
        val wm = windowManager ?: return
        content = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            setPadding(18, 12, 18, 18)
            text = "Loading widget board…"
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 4, 8, 4)
        }
        header.addView(TextView(this).apply {
            text = "TV Widget Lab"
            textSize = 18f
            setTextColor(0xFF8BE9E0.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(Button(this).apply {
            text = "↻ Refresh"
            isAllCaps = false
            setOnClickListener { content?.text = buildStatusText() }
        })
        header.addView(Button(this).apply {
            text = "×"
            contentDescription = "Hide widget board"
            isAllCaps = false
            setOnClickListener { stopSelf() }
        })

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF21A2633.toInt())
            addView(header)
            addView(content)
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 28
            y = 80
        }

        try {
            wm.addView(panel, params)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun buildStatusText(): String {
        val now = Date()
        val clockPattern = if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm a"
        val clock = SimpleDateFormat(clockPattern, Locale.getDefault()).format(now)
        val day = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalMb = memoryInfo.totalMem / (1024.0 * 1024.0)
        val availableMb = memoryInfo.availMem / (1024.0 * 1024.0)
        val usedMb = (totalMb - availableMb).coerceAtLeast(0.0)
        val ramPercent = if (totalMb > 0) ((usedMb / totalMb) * 100).toInt() else 0

        val stat = StatFs(filesDir.absolutePath)
        val totalStorage = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
        val freeStorage = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val usedStorage = (totalStorage - freeStorage).coerceAtLeast(0.0)
        val storagePercent = if (totalStorage > 0) (usedStorage / totalStorage * 100).toInt() else 0

        return "$clock  •  $day\n\n" +
            "RAM: $ramPercent% used\n" +
            "${formatter.format(usedMb / 1024)} GB used / ${formatter.format(totalMb / 1024)} GB total\n\n" +
            "App-accessible storage: $storagePercent% used\n" +
            "${formatter.format(usedStorage)} GB used / ${formatter.format(totalStorage)} GB total\n\n" +
            "Readings refresh automatically every 3 seconds. Storage shown is app-accessible storage, not total TV storage."
    }

    override fun onDestroy() {
        handler.removeCallbacks(updater)
        try {
            panel?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {}
        panel = null
        content = null
        windowManager = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW = "com.tvwidgetlab.action.SHOW"
        const val ACTION_HIDE = "com.tvwidgetlab.action.HIDE"
        const val ACTION_REFRESH = "com.tvwidgetlab.action.REFRESH"
    }
}
