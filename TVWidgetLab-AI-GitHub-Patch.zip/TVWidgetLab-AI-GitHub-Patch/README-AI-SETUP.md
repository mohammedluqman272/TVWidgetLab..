# TV Widget Lab — secure AI backend patch

This patch changes the Android app to call a private Cloudflare Worker. The OpenAI API key is stored as a Cloudflare Worker secret and is never entered into the TV app or committed to GitHub.

## Important account and billing note

If the app user is under 18, a parent or guardian must approve and manage the API account and any billing. Never paste an API key into chat, Kotlin source, a GitHub file, or a public issue.

## 1. Add these files to the existing GitHub repository

Upload/replace the paths in this patch, preserving the folder structure:

- `app/src/main/java/com/tvwidgetlab/AiService.kt`
- `app/src/main/java/com/tvwidgetlab/MainActivity.kt`
- `backend/worker.js`
- `backend/wrangler.toml`
- `.github/workflows/deploy-ai-backend.yml`

The other Android project files in this patch are included as context. Do not replace unrelated project files if they have changed since this patch was prepared.

## 2. Prepare Cloudflare

A Cloudflare account is required to host the always-available Worker. Create a Cloudflare API token that has permission to edit/deploy Workers for the intended account. Find the Cloudflare Account ID in the account dashboard.

## 3. Add GitHub Actions secrets

In the repository, open **Settings → Secrets and variables → Actions → New repository secret**. Add these four secrets:

- `CLOUDFLARE_API_TOKEN` — Cloudflare deployment token
- `CLOUDFLARE_ACCOUNT_ID` — Cloudflare account ID
- `OPENAI_API_KEY` — API key created and managed by the parent/guardian
- `TVLAB_ACCESS_CODE` — a long, random access phrase/code that you choose and keep private

Do not put any of these values into repository files. The workflow passes the OpenAI key and access code to Wrangler as Worker secrets.

## 4. Deploy the backend

Open **Actions → Deploy TV Widget Lab AI backend → Run workflow**. The workflow also runs automatically when files under `backend/` change on the `main` branch.

After a successful deployment, Cloudflare will show a Worker URL similar to:

`https://tv-widget-lab-ai.<your-workers-subdomain>.workers.dev`

The health endpoint should respond at `/health` with a small JSON status. The chat endpoint is `/chat`.

## 5. Configure the TV app

Build and install the Android APK from the normal **Build TV Widget Lab APK** workflow. In TV Widget Lab, open **AI → Connect AI backend** and enter:

- Backend URL: the Worker URL shown by Cloudflare (without `/chat` is fine)
- Access code: the exact value stored as `TVLAB_ACCESS_CODE`

The app automatically adds `/chat` to the URL. Do not enter the OpenAI API key in the TV app.

## 6. Model selection and spending protection

The Worker defaults to `gpt-4o-mini` in `backend/wrangler.toml`. This is a configurable example model, not a claim that another model is enabled on the API account. Change it only to a model currently available to the API project, then redeploy.

Set a project budget/usage alert in the OpenAI platform. Also configure a Cloudflare rate-limiting rule for the Worker route `/chat`. The access code is an additional gate, not a substitute for rate limits or account spending controls. Since the app must hold the access code to call the Worker, a determined person with access to the device could extract it.

## What this patch does and does not do

- Sends text prompts from the app to the private Worker and returns an AI answer.
- Keeps the OpenAI API key on the Worker, not in the APK.
- Preserves the app's existing local command handling; local commands are handled by Android before a prompt is sent to the AI.
- Does not yet implement full AI tool/function calling, persistent multi-turn conversation history, or direct control of every TV setting.
- Voice still depends on Android speech-recognition and microphone services available on the TV.

## Validation

The source files and workflow were prepared, but an Android SDK/Gradle build and a live Cloudflare/OpenAI deployment have not been run from this environment. Use the GitHub Actions build and deploy workflows to validate them. Do not treat a successful backend deployment alone as proof that the APK works on the TCL TV.
