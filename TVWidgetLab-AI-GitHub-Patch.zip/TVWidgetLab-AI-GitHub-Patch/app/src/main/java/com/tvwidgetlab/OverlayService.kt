package com.tvwidgetlab

import android.app.ActivityManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.text.format.DateFormat
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var clockValue: TextView? = null
    private var dateValue: TextView? = null
    private var ramValue: TextView? = null
    private var ramDetail: TextView? = null
    private var storageValue: TextView? = null
    private var storageDetail: TextView? = null
    private var statusValue: TextView? = null
    private var cleanButton: Button? = null
    private var refreshButton: Button? = null
    private var closeButton: Button? = null
    private var expandedPanel: LinearLayout? = null
    private var expandedWidth = 0
    private var expandedParams: WindowManager.LayoutParams? = null
    private var dashboardBody: LinearLayout? = null
    private var sectionHeading: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val formatter = DecimalFormat("0.0")
    private var homeReceiverRegistered = false

    // Android TV sends CLOSE_SYSTEM_DIALOGS with reason=homekey when Home is pressed.
    // This is a best-effort signal; Android versions/vendor builds may handle it differently.
    private val homeKeyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_CLOSE_SYSTEM_DIALOGS &&
                intent.getStringExtra("reason") == "homekey"
            ) {
                stopSelf()
            }
        }
    }

    private val updater = object : Runnable {
        override fun run() {
            refreshReadings()
            handler.postDelayed(this, 5000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(homeKeyReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(homeKeyReceiver, filter)
            }
            homeReceiverRegistered = true
        } catch (_: Exception) {
            homeReceiverRegistered = false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_PANEL -> { hideExpandedPanel(); return START_NOT_STICKY }
            ACTION_OPEN_PANEL -> { showExpandedPanel(); return START_NOT_STICKY }
            ACTION_REFRESH -> {
                refreshReadings()
                return START_NOT_STICKY
            }
        }
        if (windowManager == null) windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (panel == null) createOverlay()
        handler.removeCallbacks(updater)
        refreshReadings()
        handler.postDelayed(updater, 5000L)
        return START_NOT_STICKY
    }

    private fun createOverlay() {
        val wm = windowManager ?: return

        // Compact, single-row status bar designed to leave most of the TV visible.
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(8), dp(7))
            setBackgroundColor(Color.rgb(14, 27, 40))
            // Allow Android TV's D-pad to move focus among the buttons.
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        val timeBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), 0, dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(dp(100), dp(48))
        }
        clockValue = TextView(this).apply {
            text = "--:--"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        dateValue = TextView(this).apply {
            text = "Loading date"
            textSize = 9f
            setTextColor(Color.rgb(184, 199, 217))
            maxLines = 1
        }
        timeBlock.addView(clockValue)
        timeBlock.addView(dateValue)
        outer.addView(timeBlock)
        outer.addView(separator())

        outer.addView(compactMetric("RAM", "--", "--") { value, detail ->
            ramValue = value
            ramDetail = detail
        }, LinearLayout.LayoutParams(dp(82), dp(48)))
        outer.addView(separator())
        outer.addView(compactMetric("STORAGE", "--", "--") { value, detail ->
            storageValue = value
            storageDetail = detail
        }, LinearLayout.LayoutParams(dp(94), dp(48)))
        outer.addView(separator())

        cleanButton = smallButton("PANEL", false) { showExpandedPanel() }.apply { textSize = 10f; minHeight = dp(38) }
        outer.addView(cleanButton)
        outer.addView(smallButton("AI", false) { openDashboardPage("AI") }.apply { textSize = 10f; minHeight = dp(38) })

        refreshButton = smallButton("↻", false) {
            refreshReadings()
            statusValue?.text = "Updated"
        }.apply { textSize = 16f; minHeight = dp(38) }
        outer.addView(refreshButton)

        closeButton = smallButton("×", false) { stopSelf() }.apply {
            textSize = 17f
            minHeight = dp(38)
        }
        outer.addView(closeButton)

        statusValue = TextView(this).apply { text = "Updated"; visibility = View.GONE }
        panel = outer

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            // FLAG_NOT_FOCUSABLE prevented the TV remote's D-pad from reaching these buttons.
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(14)
            y = dp(14)
        }
        try {
            wm.addView(panel, params)
            // Give the first actual control focus so the TV remote can operate it.
            cleanButton?.post {
                cleanButton?.requestFocus()
            }
        } catch (_: Exception) {
            panel = null
            stopSelf()
        }
    }


    private fun showExpandedPanel() {
        if (expandedPanel != null) return
        val wm = windowManager ?: return
        val screen = resources.displayMetrics
        if (expandedWidth == 0) expandedWidth = (screen.widthPixels * 0.40f).toInt().coerceAtLeast(dp(300))
        expandedWidth = expandedWidth.coerceIn(dp(300), (screen.widthPixels * 0.72f).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(12, 25, 39))
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "TV WIDGET LAB"; textSize = 17f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
        })
        header.addView(smallButton("−", false) { resizeExpanded(-dp(36)) })
        header.addView(smallButton("+", false) { resizeExpanded(dp(36)) })
        header.addView(smallButton("×", false) { hideExpandedPanel() })
        root.addView(header)
        sectionHeading = TextView(this).apply {
            text = "SYSTEM MONITOR"; textSize = 11f; setTextColor(Color.rgb(92, 220, 220))
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(sectionHeading)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(dp(126), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }
        dashboardBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, dp(8)) }
        scroll.addView(dashboardBody)
        listOf("System Monitor", "Network", "Everyday", "Controls", "Settings").forEach { name ->
            nav.addView(smallButton(name, true) { showDashboardSection(name) }.apply { textSize = 11f })
        }
        row.addView(nav); row.addView(scroll)
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            expandedWidth, (screen.heightPixels * 0.82f).toInt(), type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; x = dp(8) }
        try {
            wm.addView(root, params)
            expandedPanel = root; expandedParams = params
            showDashboardSection("System Monitor")
        } catch (_: Exception) { expandedPanel = null; expandedParams = null }
    }

    private fun showDashboardSection(name: String) {
        sectionHeading?.text = name.uppercase(Locale.getDefault())
        val body = dashboardBody ?: return
        body.removeAllViews()
        fun info(title: String, value: String, detail: String) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(9), dp(12), dp(9))
                setBackgroundColor(Color.rgb(34, 49, 65))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            }
            card.addView(TextView(this).apply { text = title; textSize = 10f; setTextColor(Color.rgb(139, 233, 224)) })
            card.addView(TextView(this).apply { text = value; textSize = 21f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(0, dp(3), 0, dp(2)) })
            card.addView(TextView(this).apply { text = detail; textSize = 11f; setTextColor(Color.rgb(184, 199, 217)) })
            body.addView(card)
        }
        when (name) {
            "System Monitor" -> {
                info("RAM", ramValue?.text?.toString() ?: "--", ramDetail?.text?.toString() ?: "System memory")
                info("INTERNAL STORAGE", storageValue?.text?.toString() ?: "--", storageDetail?.text?.toString() ?: "Device data partition")
                info("CPU", "Unavailable", "This Android TV build does not expose a reliable CPU reading to this app")
                info("TEMPERATURE", "Unavailable", "No reliable device temperature sensor is currently exposed")
                body.addView(smallButton("Refresh Readings", true) { refreshReadings(); showDashboardSection(name) })
            }
            "Network" -> {
                info("NETWORK", "Open network dashboard", "View Android-reported connection and transport details")
                body.addView(smallButton("Open Network Dashboard", true) { openDashboardPage("Network") })
            }
            "Everyday" -> {
                info("CLOCK", clockValue?.text?.toString() ?: "--:--", dateValue?.text?.toString() ?: "")
                body.addView(smallButton("Open Stopwatch", true) { openDashboardPage("Everyday") })
            }
            "Controls" -> {
                info("FREE RAM", "Safe app management", "Android manages memory automatically. Select an app to open its system info page; this app cannot force-stop other apps silently.")
                body.addView(smallButton("Choose an app to manage", true) {
                    val i = Intent(this@OverlayService, MainActivity::class.java).putExtra(MainActivity.EXTRA_CLEAN_MEMORY, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                })
                body.addView(smallButton("Refresh Readings", true) { refreshReadings() })
                body.addView(smallButton("Open TV Controls", true) { openDashboardPage("Controls") })
            }
            "Settings" -> {
                info("PANEL WIDTH", "${expandedWidth / resources.displayMetrics.density.toInt().coerceAtLeast(1)} dp", "Use − / + or left and right remote keys")
                body.addView(smallButton("Narrow panel", true) { resizeExpanded(-dp(36)) })
                body.addView(smallButton("Widen panel", true) { resizeExpanded(dp(36)) })
                body.addView(smallButton("Open App Settings", true) { openDashboardPage("Settings") })
                body.addView(smallButton("Open Widget Gallery", true) { openDashboardPage("Widgets") })
                body.addView(smallButton("Open Profiles", true) { openDashboardPage("Profiles") })
            }
        }
    }

    private fun openDashboardPage(page: String) {
        try {
            val intent = Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_START_PAGE, page)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        } catch (_: Exception) { }
    }

    private fun resizeExpanded(delta: Int) {
        val params = expandedParams ?: return
        val max = (resources.displayMetrics.widthPixels * 0.72f).toInt()
        expandedWidth = (expandedWidth + delta).coerceIn(dp(300), max)
        params.width = expandedWidth
        try { windowManager?.updateViewLayout(expandedPanel, params) } catch (_: Exception) { }
    }

    private fun hideExpandedPanel() {
        try { expandedPanel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        expandedPanel = null; expandedParams = null; dashboardBody = null; sectionHeading = null
    }

    private fun separator(): View = View(this).apply {
        setBackgroundColor(Color.rgb(56, 78, 96))
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(30)).apply {
            leftMargin = dp(3)
            rightMargin = dp(3)
        }
    }

    private fun compactMetric(
        label: String,
        initialValue: String,
        initialDetail: String,
        onCreated: (TextView, TextView) -> Unit
    ): View {
        val block = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, dp(4), 0)
        }
        block.addView(TextView(this).apply {
            text = label
            textSize = 9f
            setTextColor(Color.rgb(139, 233, 224))
        })
        val value = TextView(this).apply {
            text = initialValue
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        val detail = TextView(this).apply {
            text = initialDetail
            textSize = 8f
            setTextColor(Color.rgb(184, 199, 217))
            maxLines = 1
        }
        block.addView(value)
        block.addView(detail)
        onCreated(value, detail)
        return block
    }

    private fun makeCard(title: String, initialValue: String, type: String, onCreated: (TextView, TextView) -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            setBackgroundColor(Color.rgb(34, 49, 65))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(139, 233, 224))
        })
        val value = TextView(this).apply {
            text = initialValue
            textSize = if (type == "clock") 26f else 21f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(3), 0, dp(2))
        }
        card.addView(value)
        val detail = TextView(this).apply {
            text = if (type == "clock") "Loading date…" else "Loading details…"
            textSize = 12f
            setTextColor(Color.rgb(184, 199, 217))
        }
        card.addView(detail)
        onCreated(value, detail)
        return card
    }

    private fun smallButton(label: String, wide: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = if (wide) 12f else 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 72, 91))
            minHeight = dp(if (wide) 44 else 40)
            // Make remote focus unmistakable without relying on pointer hover.
            isFocusable = true
            isFocusableInTouchMode = true
            setOnFocusChangeListener { view, hasFocus ->
                view.setBackgroundColor(
                    if (hasFocus) Color.rgb(0, 150, 136) else Color.rgb(48, 72, 91)
                )
                view.scaleX = if (hasFocus) 1.04f else 1.0f
                view.scaleY = if (hasFocus) 1.04f else 1.0f
            }
            setPadding(dp(8), 0, dp(8), 0)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
            setOnKeyListener { _, keyCode, event ->
                if (expandedPanel != null && event.action == KeyEvent.ACTION_DOWN &&
                    (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                    resizeExpanded(if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) dp(24) else -dp(24))
                    true
                } else false
            }
            layoutParams = LinearLayout.LayoutParams(
                if (wide) LinearLayout.LayoutParams.MATCH_PARENT else LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(if (wide) 44 else 40)
            ).apply { if (wide) topMargin = dp(8) else leftMargin = dp(6) }
        }
    }

    private fun refreshReadings() {
        val now = Date()
        val clockPattern = if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm a"
        clockValue?.text = SimpleDateFormat(clockPattern, Locale.getDefault()).format(now)
        dateValue?.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalMb = memoryInfo.totalMem / (1024.0 * 1024.0)
        val availableMb = memoryInfo.availMem / (1024.0 * 1024.0)
        val usedMb = (totalMb - availableMb).coerceAtLeast(0.0)
        val ramPercent = if (totalMb > 0) ((usedMb / totalMb) * 100).toInt() else 0
        ramValue?.text = "$ramPercent% used"
        ramDetail?.text = "${formatter.format(usedMb / 1024)} / ${formatter.format(totalMb / 1024)} GB"

        val stat = StatFs(android.os.Environment.getDataDirectory().absolutePath)
        val totalStorage = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
        val freeStorage = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val usedStorage = (totalStorage - freeStorage).coerceAtLeast(0.0)
        val storagePercent = if (totalStorage > 0) (usedStorage / totalStorage * 100).toInt() else 0
        storageValue?.text = "$storagePercent% used"
        storageDetail?.text = "${formatter.format(usedStorage)} / ${formatter.format(totalStorage)} GB app"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(updater)
        if (homeReceiverRegistered) {
            try { unregisterReceiver(homeKeyReceiver) } catch (_: Exception) { }
            homeReceiverRegistered = false
        }
        hideExpandedPanel()
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panel = null
        clockValue = null
        dateValue = null
        ramValue = null
        ramDetail = null
        storageValue = null
        storageDetail = null
        statusValue = null
        cleanButton = null
        refreshButton = null
        closeButton = null
        windowManager = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW = "com.tvwidgetlab.action.SHOW"
        const val ACTION_HIDE = "com.tvwidgetlab.action.HIDE"
        const val ACTION_REFRESH = "com.tvwidgetlab.action.REFRESH"
        const val ACTION_HIDE_PANEL = "com.tvwidgetlab.action.HIDE_PANEL"
        const val ACTION_OPEN_PANEL = "com.tvwidgetlab.action.OPEN_PANEL"
    }
}
