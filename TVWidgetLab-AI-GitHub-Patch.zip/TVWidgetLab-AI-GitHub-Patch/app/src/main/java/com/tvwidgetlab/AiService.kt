package com.tvwidgetlab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** TV client for the private Cloudflare Worker. The OpenAI API key never lives in this APK. */
class AiService(context: Context) {
    private val prefs = context.getSharedPreferences("tvlab_ai", Context.MODE_PRIVATE)

    fun saveConfiguration(workerUrl: String, accessCode: String) {
        require(workerUrl.startsWith("https://")) { "The backend URL must use HTTPS." }
        require(accessCode.isNotBlank()) { "Enter the TV Widget Lab access code." }
        prefs.edit()
            .putString("worker_url", workerUrl.trim().trimEnd('/'))
            .putString("access_code", accessCode.trim())
            .apply()
    }

    fun endpoint(): String = prefs.getString("worker_url", "") ?: ""
    fun isConfigured(): Boolean = endpoint().startsWith("https://") &&
        !prefs.getString("access_code", "").isNullOrBlank()

    fun ask(prompt: String): String {
        require(prompt.isNotBlank()) { "Enter a message first." }
        require(prompt.length <= 6000) { "Please keep the message under 6,000 characters." }
        val baseUrl = endpoint()
        require(baseUrl.startsWith("https://")) { "Configure your secure AI backend URL first." }
        val accessCode = prefs.getString("access_code", null)
            ?: throw IllegalStateException("Enter the TV Widget Lab backend access code in AI Settings.")
        val target = if (baseUrl.endsWith("/chat")) baseUrl else "$baseUrl/chat"
        val connection = (URL(target).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("X-TVLAB-ACCESS-CODE", accessCode)
        }
        try {
            val body = JSONObject().put("prompt", prompt)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val message = try { JSONObject(response).optString("error", "AI backend error") }
                    catch (_: Exception) { "AI backend error" }
                throw IllegalStateException("$message (HTTP $status)")
            }
            val json = JSONObject(response)
            return json.optString("reply").trim().ifBlank {
                throw IllegalStateException("The AI backend returned an empty response.")
            }
        } finally {
            connection.disconnect()
        }
    }
}
