const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-TVLAB-ACCESS-CODE",
  "Content-Type": "application/json; charset=utf-8",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/health") {
      return json({ ok: true, service: "TV Widget Lab AI backend" });
    }
    if (request.method !== "POST" || url.pathname !== "/chat") {
      return json({ error: "Not found" }, 404);
    }
    if (!env.OPENAI_API_KEY || !env.TVLAB_ACCESS_CODE) {
      return json({ error: "Backend secrets are not configured." }, 503);
    }

    const suppliedCode = request.headers.get("X-TVLAB-ACCESS-CODE") || "";
    if (!safeEqual(suppliedCode, env.TVLAB_ACCESS_CODE)) {
      return json({ error: "Invalid TV Widget Lab access code." }, 401);
    }

    const contentLength = Number(request.headers.get("Content-Length") || "0");
    if (contentLength > 12000) return json({ error: "Request is too large." }, 413);

    let input;
    try { input = await request.json(); }
    catch { return json({ error: "Request must contain valid JSON." }, 400); }

    const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
    if (!prompt) return json({ error: "Message cannot be empty." }, 400);
    if (prompt.length > 6000) return json({ error: "Message is too long (maximum 6,000 characters)." }, 413);

    const model = env.OPENAI_MODEL || "gpt-4o-mini";
    let upstream;
    try {
      upstream = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          messages: [
            {
              role: "system",
              content: "You are TV Widget Lab's calm, concise assistant for a television. Answer helpfully and safely. You cannot directly control the TV from this endpoint. Never claim an action was completed unless the TV app separately confirms it. For TV actions, explain that the app's local command controls must perform them. Keep answers suitable for a general audience."
            },
            { role: "user", content: prompt }
          ],
          max_tokens: 500,
          temperature: 0.4
        }),
      });
    } catch {
      return json({ error: "Could not reach the AI provider. Check the backend network connection." }, 502);
    }

    const raw = await upstream.text();
    let result;
    try { result = JSON.parse(raw); }
    catch { return json({ error: "The AI provider returned an unreadable response." }, 502); }

    if (!upstream.ok) {
      const providerMessage = result?.error?.message || "AI provider request failed.";
      return json({ error: providerMessage.slice(0, 300) }, upstream.status === 429 ? 429 : 502);
    }

    const reply = result?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return json({ error: "The AI provider returned an empty answer." }, 502);
    }
    return json({ reply: reply.trim(), model });
  }
};
